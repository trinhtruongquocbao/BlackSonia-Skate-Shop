module.exports = {
  DB: "mongodb+srv://dbListName:qweasdzxc123@cluster0.d5smv.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
};
